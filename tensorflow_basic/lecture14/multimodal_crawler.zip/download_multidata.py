# import requests
from __future__ import unicode_literals
import os
import re
import sys
import time
import json
import random
import pickle
from tqdm import tqdm
from pprint import pprint

import urllib
import urllib.request as request

from bs4 import BeautifulSoup
import selenium.webdriver as webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support import expected_conditions as EC

import nltk
nltk.download('punkt')
from nltk.stem import PorterStemmer
from nltk.tokenize.regexp import RegexpTokenizer
from types import SimpleNamespace

#def get_image(img_url, save_dir, idx):
def get_images(url : str, driver : object, save_dir: str, idx : int):
    try:
        urls, num_imgs = _get_several_images(driver, url)
        
        if num_imgs > 1:
            for img_idx, img_url in enumerate(urls):
                filename =  save_dir +'/' + 'image_' + str(idx) + f'_({img_idx})'+'.png'
                request.urlretrieve(img_url, filename)
        else:
            filename =  save_dir +'/' + 'image_' + str(idx) + '.png'
            request.urlretrieve(urls[0], filename)
        
    except Exception as e:
        if not os.path.exists(config.LOG_PATH):
            os.makedirs(config.LOG_PATH)
            
        with open(config.LOG_PATH + '/' + config.FILE_LOG, 'a') as writer:
            writer.write(e.__class__.__name__)
            writer.write('\t')
            writer.write(url)
            writer.write('\n')

        print("Image not found error", str(e))

def _get_several_images(driver, url):
    # url="https://www.instagram.com/p/B8BBJCzAR8g/"
    driver.get(url)
    driver.implicitly_wait(5)

    # Image Set in a post
    temp = []
    number_image = 1
    while True:
        time.sleep(2)
        pageString = driver.page_source
        soup = BeautifulSoup(pageString, "lxml")
        if len(soup.select('img')) == 1:
            break
        try:
            imgs = soup.select('img')[number_image]

        except IndexError:
            break
        
        if 'src' not in imgs.attrs:
            continue
        imgs = imgs.attrs['src']
        temp.append(imgs)
        try:
            driver.find_element_by_class_name("coreSpriteRightChevron").click()  # The number of Image
            number_image += 1

        except NoSuchElementException:
            break
    return temp, number_image

def _clean_str(string):
    # Yoon kim English Preprocessing Revise
    string = re.sub(r"[.,!?\'\`]", " ", string)
    string = re.sub(r"\’s", " \'s", string)
    string = re.sub(r"\’ve", " \'ve", string)
    string = re.sub(r"n\’t", " n\'t", string)
    string = re.sub(r"\’re", " \'re", string)
    string = re.sub(r"\’d", " \'d", string)
    string = re.sub(r"\’ll", " \'ll", string)
    string = re.sub(r"\.", " .", string)
    string = re.sub(r",", " , ", string)
    string = re.sub(r"!", " ! ", string)
    string = re.sub(r"\(", " \( ", string)
    string = re.sub(r"\)", " \) ", string)
    string = re.sub(r"\?", " \? ", string)
    string = re.sub(r"\s{2,}", " ", string)
    return string.strip()

def _rm_imoge(text:str):
    emoji_pattern = re.compile("["
                    u"\U0001F600-\U0001F64F"  # emoticons
                    u"\U0001F300-\U0001F5FF"  # symbols & pictographs
                    u"\U0001F680-\U0001F6FF"  # transport & map symbols
                    u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
                    u"\U00002702-\U000027B0"
                    u"\U000024C2-\U0001F251"
                    u"\U0001f926-\U0001f937"
                    u'\U00010000-\U0010ffff'
                    u"\u200d"
                    u"\u2640-\u2642"
                    u"\u2600-\u2B55"
                    u"\u23cf"
                    u"\u23e9"
                    u"\u231a"
                    u"\u3030"
                    u"\ufe0f"
        "]+", flags=re.UNICODE)
    text = emoji_pattern.sub(r'', text)
    return text

def _stemmer(text, changer:object, tokenizer:object):
    words = tokenizer.tokenize(text)
    for i, word in enumerate(words):
        word = changer.stem(word)
        words[i] = word
    return ' '.join(words)

def get_lat_lon(url, driver, save_path, idx):
    driver.get(url)
    wait = WebDriverWait(driver, 5)
    wait.until(EC.presence_of_element_located((By.CLASS_NAME, "cq2ai")))

    # soup = BeautifulSoup(driver.page_source, "html.parser")
    # loc = soup.find("a",{"class": "O4GlU"})

    # if loc is None:
    #     location = ''
    # else:
    #     location = loc.text
    
    #     driver.find_element_by_link_text(location).click()

    body = driver.find_element_by_class_name('JF9hh')
    table = BeautifulSoup(body.get_attribute("innerHTML"), features="html.parser")
    suburl = str(table.find('a').attrs.get('href'))
    loc = suburl.split('/')[-2]
    locurl = config.ROOT_URL + suburl

    driver.get(locurl)
    x = driver.find_element_by_xpath("//meta[@property='place:location:latitude']")
    lat = x.get_attribute('content')

    y = driver.find_element_by_xpath("//meta[@property='place:location:longitude']")
    lon = y.get_attribute('content')
    
    msg = "Success getting latitude and longitude for location[{}]: ({}, {})".format(loc, lat, lon)

    with open(os.path.join(save_path, f'lat_lon_{idx}.txt'), 'w', encoding='utf-8') as writer:
        writer.write(f'{loc},{lat},{lon}')
    
    print(msg)
    print("Sucessfully lat lon saved")

def get_text_tag_loc(url:str, driver:object, save_dir:str, idx:int, charger:object, tokenizer:object):
    # change url
    driver.get(url)

    soup = BeautifulSoup(driver.page_source, "html.parser")
    
    texts = soup.find("div",{"class": "C4VMK"})

    # exception cases 
    if texts is None:
        text=''
        tags=[]
        
    else:
        span_text = texts.find('span', {"class" : ""})

        words = span_text.text.split(' ')
        words_=[]
        for word in words:
            try:
                if word[0] == '#':
                    pass
                else:
                    words_.extend([word])
            except:
                pass
        
        ######################################################
        ################  text preprocess ####################
        text = ' '.join(words_)
        # simple clean
        text = re.sub('\#[a-zA-Z]{1,}','',text)
        text = _rm_imoge(text)
        text = _clean_str(text)
        
        #text = _stemmer(text, charger, tokenizer)

        ######################################################
        ################ tag preprocess ######################

        tag_list = span_text.find_all('a', {"class" : "xil3i"})
        tags=[]
        for tag in tag_list:
            tags.extend([tag.getText('</a>')])

        del words

        if len(tags) > 25:
            tags=[]
        ######################################################
        ################## location ##########################

        loc = soup.find("a",{"class": "O4GlU"})
        
        if loc is None:
            location = ''
        else:
            location = loc.text

        #########################################################
        ################## save files ###########################
        # only file is saved in case all data exist
        if len(tags) == 0 or len(text) == 0 or len(location) == 0:
            pass
            # with open('./error_urls.log', 'a') as writer:
            #     if len(tags)==0:
            #         writer.write('no tags')
            #     if len(text) ==0:
            #         writer.write('no text')
            #     else:
            #         writer.write('no location')

            #     writer.write('\t')
            #     writer.write(url)
            #     writer.write('\n')
        else:
            with open(os.path.join(save_dir, f'text_{idx}.txt'), 'w', encoding='utf-8') as writer:
                writer.write(text)
            print("text saved")
            with open(os.path.join(save_dir, f'tag_{idx}.pkl'), 'wb') as writer:
                pickle.dump(tags, writer)
            print("tags saved")
            with open(os.path.join(save_dir, f'location_{idx}.txt'), 'w', encoding='utf-8') as writer:
                writer.write(location)   
            print("loc saved")
    return texts, tags, location
    

if __name__ == '__main__':

    with open('config.json') as f:
        config = json.load(f, object_hook=lambda d: SimpleNamespace(**d))

    urls_files_path = './urls_from_hashtags/'
    # urls_files_path = config.URL_PATH
    urls = os.listdir(urls_files_path)

    changer = PorterStemmer()
    tokenizer = RegexpTokenizer("\s+", gaps=True)

    max_iter = 30 #

    for i , url in enumerate(urls): # 7-10

        urls_file_path = os.path.join(urls_files_path, url)
        save_path = './result/'+ url
        # save_path = config.ROOT_PATH + '/' +config.SAVE_FILE + '/' + url
        
        if not os.path.exists(save_path):
            os.makedirs(save_path)

        with open(urls_file_path, 'r', encoding='utf-8') as reader:
            datas = json.load(reader)
        # loading chrome driver
        driver = webdriver.Chrome("./inscrawler/bin/chromedriver.exe")
        # driver = webdriver.Chrome(config.CHROME_DRIVER)

        ########################### save image and multiple data #############################

        iters = len(datas) // max_iter # iters * max_iter = datas
        sleep_pools = [t/float(iters) for t in list(range(0, iters))]
        real_cnt=0
        #imgurl_map={}
        for idx, data in tqdm(enumerate(datas)):
            
            if idx % max_iter == 0:
                sleep_time = random.choice(sleep_pools)
                time.sleep(sleep_time)
                print(f"time sleep.... {sleep_time} sec")
                        
            try:
                text, tags, loc = get_text_tag_loc(data['key'], driver, save_path, idx, changer, tokenizer)
                
                if len(text)== 0 or len(tags) == 0 or len(loc) == 0:
                    pass

                else:
                    real_cnt+=1
                    ## if several images exist, they are saved
                    get_images(data['key'], driver, save_path, idx)
                    print("img saved")
                    get_lat_lon(data['key'],driver, save_path, idx)
                        
            except urllib.error.HTTPError:
                pass # originally it is good to write log. (with log format)
            
            except Exception as e:
                print(e.__class__.__name__)
                pass
