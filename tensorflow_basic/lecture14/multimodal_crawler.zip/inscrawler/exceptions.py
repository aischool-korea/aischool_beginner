class RetryException(Exception):
    pass
