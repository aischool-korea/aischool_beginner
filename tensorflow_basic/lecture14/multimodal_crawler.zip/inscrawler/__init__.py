from .crawler import InsCrawler
