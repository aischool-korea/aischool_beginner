# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import argparse
import json
import sys
import os
from io import open
from tqdm import tqdm

from multimodal_crawler.inscrawler.crawler import InsCrawler

def get_posts_by_user(username, number, detail, debug):
    ins_crawler = InsCrawler(has_screen=debug)
    return ins_crawler.get_user_posts(username, number, detail)


def get_profile(username):
    ins_crawler = InsCrawler()
    return ins_crawler.get_user_profile(username)


def get_profile_from_script(username):
    ins_cralwer = InsCrawler()
    return ins_cralwer.get_user_profile_from_script_shared_data(username)


def get_posts_by_hashtag(tag, number, debug):
    ins_crawler = InsCrawler(has_screen=debug)
    return ins_crawler.get_latest_posts_by_tag(tag, number)


def output(data, filepath):
    out = json.dumps(data, ensure_ascii=False)
    if filepath:
        with open(filepath, "w", encoding="utf8") as f:
            f.write(out)
    else:
        print(out)


if __name__ == "__main__":

    with open('./popular_tags/hashtags.txt', 'r', encoding='utf-8') as read:
        top_tags = read.readlines()
    top_tags = list(map(lambda x : x.replace('\n',''), top_tags))

    if not os.path.exists('./urls_from_hashtags/'): # path 설정
        os.makedirs('./urls_from_hashtags/')

    for tag in tqdm(top_tags):
        output(
            get_posts_by_hashtag(tag, 30, True), './urls_from_hashtags/'+ tag+ '.json'
        )

