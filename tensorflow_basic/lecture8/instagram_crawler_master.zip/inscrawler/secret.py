import os

username = os.environ.get('USERNAME', '')
password = os.environ.get('PASSWORD', '')
